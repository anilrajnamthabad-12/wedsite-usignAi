import os
import uuid
from functools import wraps
from datetime import datetime

from flask import (
    Flask, render_template, request, redirect, url_for, flash,
    session, jsonify, send_from_directory, abort
)
from werkzeug.utils import secure_filename

from config import Config, DEFAULT_BUSINESS, DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_PASSWORD
from models import db, Settings, Admin, Project, Enquiry, Testimonial, PROJECT_CATEGORIES, PROJECT_SUBCATEGORIES

SERVICES = [
    {"slug": "wooden-doors", "name": "Wooden Doors", "category": "doors",
     "desc": "Solid, long-lasting wooden doors crafted to match your home's style and security needs.",
     "img": "https://placehold.co/500x360/5b3a24/f5ede1?text=Wooden+Doors"},
    {"slug": "wooden-windows", "name": "Wooden Windows", "category": "windows",
     "desc": "Weather-resistant wooden window frames with smooth finishing and precise fitting.",
     "img": "https://placehold.co/500x360/6b4429/f5ede1?text=Wooden+Windows"},
    {"slug": "main-doors", "name": "Main Doors", "category": "doors",
     "desc": "Grand entrance doors in teak and premium hardwood, built to make a first impression.",
     "img": "https://placehold.co/500x360/4a2e1c/f5ede1?text=Main+Doors"},
    {"slug": "bedroom-doors", "name": "Bedroom Doors", "category": "doors",
     "desc": "Quiet, sturdy and elegant doors designed for comfort and privacy.",
     "img": "https://placehold.co/500x360/5b3a24/f5ede1?text=Bedroom+Doors"},
    {"slug": "designer-doors", "name": "Designer Doors", "category": "doors",
     "desc": "Custom carved and panelled doors that turn a doorway into a design statement.",
     "img": "https://placehold.co/500x360/6b4429/f5ede1?text=Designer+Doors"},
    {"slug": "modular-kitchen", "name": "Modular Kitchen", "category": "kitchen",
     "desc": "Space-efficient modular kitchens with durable shutters and smart storage.",
     "img": "https://placehold.co/500x360/4a2e1c/f5ede1?text=Modular+Kitchen"},
    {"slug": "wardrobes", "name": "Wardrobes", "category": "wardrobes",
     "desc": "Sliding, hinged and walk-in wardrobes tailored to your room and storage needs.",
     "img": "https://placehold.co/500x360/5b3a24/f5ede1?text=Wardrobes"},
    {"slug": "tv-units", "name": "TV Units", "category": "tv-units",
     "desc": "Modern wall-mounted and floor TV units with cable management and display shelves.",
     "img": "https://placehold.co/500x360/6b4429/f5ede1?text=TV+Units"},
    {"slug": "pooja-units", "name": "Pooja Units", "category": "pooja-units",
     "desc": "Traditional and contemporary pooja mandirs crafted with care and fine detailing.",
     "img": "https://placehold.co/500x360/4a2e1c/f5ede1?text=Pooja+Units"},
    {"slug": "wooden-furniture", "name": "Wooden Furniture", "category": "furniture",
     "desc": "Beds, dining tables, sofas and more, built from solid, seasoned wood.",
     "img": "https://placehold.co/500x360/5b3a24/f5ede1?text=Wooden+Furniture"},
    {"slug": "office-furniture", "name": "Office Furniture", "category": "office-furniture",
     "desc": "Functional and professional office desks, cabins and storage units.",
     "img": "https://placehold.co/500x360/6b4429/f5ede1?text=Office+Furniture"},
    {"slug": "wooden-ceiling", "name": "Wooden Ceiling", "category": "wooden-ceiling",
     "desc": "False wooden ceilings and panelling that add warmth and depth to any room.",
     "img": "https://placehold.co/500x360/4a2e1c/f5ede1?text=Wooden+Ceiling"},
    {"slug": "cupboards", "name": "Cupboards", "category": "cupboards",
     "desc": "Built-in and free-standing cupboards designed for durability and easy use.",
     "img": "https://placehold.co/500x360/5b3a24/f5ede1?text=Cupboards"},
    {"slug": "custom-woodwork", "name": "Custom Woodwork", "category": "other",
     "desc": "Have something specific in mind? We build fully custom wood pieces to order.",
     "img": "https://placehold.co/500x360/6b4429/f5ede1?text=Custom+Woodwork"},
    {"slug": "interior-wood-decoration", "name": "Interior Wood Decoration", "category": "other",
     "desc": "Decorative wood panelling, partitions and accents that elevate your interiors.",
     "img": "https://placehold.co/500x360/4a2e1c/f5ede1?text=Interior+Decoration"},
]


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    os.makedirs(os.path.dirname(Config.SQLALCHEMY_DATABASE_URI.replace("sqlite:///", "")), exist_ok=True) \
        if Config.SQLALCHEMY_DATABASE_URI.startswith("sqlite:///") else None
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

    db.init_app(app)

    with app.app_context():
        db.create_all()
        seed_defaults()

    register_routes(app)
    register_context_processors(app)
    return app


def seed_defaults():
    """Populate Settings / Admin / demo Projects & Testimonials on first run only."""
    if Settings.query.first() is None:
        s = Settings(**{k: v for k, v in DEFAULT_BUSINESS.items() if k in Settings.__table__.columns.keys()})
        db.session.add(s)

    if Admin.query.first() is None:
        a = Admin(username=DEFAULT_ADMIN_USERNAME)
        a.set_password(DEFAULT_ADMIN_PASSWORD)
        db.session.add(a)

    if Project.query.first() is None:
        demo = [
            dict(title="Teak Wood Main Door - Kompally", category="doors", subcategory="Main Door",
                 cover_image="https://placehold.co/800x600/4a2e1c/f5ede1?text=Main+Door+Project",
                 gallery_images="https://placehold.co/800x600/4a2e1c/f5ede1?text=Image+1,https://placehold.co/800x600/5b3a24/f5ede1?text=Image+2",
                 before_image="https://placehold.co/800x600/2b1b12/c9a227?text=Before",
                 after_image="https://placehold.co/800x600/4a2e1c/f5ede1?text=After",
                 location="Kompally, Hyderabad", material="Burma Teak Wood", duration="12 days",
                 completion_year="2025",
                 description="A solid teak main door with traditional carving, designed to be the grand entrance of a family home. Placeholder project - replace with your own work.",
                 customer_requirements="Termite resistant wood, traditional carved pattern, matching door frame.",
                 testimonial_text="Excellent finishing and good quality woodwork. The team completed our main door beautifully.",
                 testimonial_author="Placeholder Customer", is_featured=True),
            dict(title="Modular Kitchen - Miyapur", category="kitchen", subcategory="L-Shaped Kitchen",
                 cover_image="https://placehold.co/800x600/5b3a24/f5ede1?text=Modular+Kitchen",
                 gallery_images="https://placehold.co/800x600/5b3a24/f5ede1?text=Image+1,https://placehold.co/800x600/6b4429/f5ede1?text=Image+2",
                 location="Miyapur, Hyderabad", material="Marine Plywood, Laminate Finish", duration="18 days",
                 completion_year="2025",
                 description="An L-shaped modular kitchen with soft-close shutters and optimised storage. Placeholder project - replace with your own work.",
                 customer_requirements="Maximum storage, easy-clean surfaces, modern look.",
                 testimonial_text="Very organised process from measurement to installation. Happy with the final result.",
                 testimonial_author="Placeholder Customer", is_featured=True),
            dict(title="Sliding Wardrobe - Kukatpally", category="wardrobes", subcategory="Sliding Wardrobe",
                 cover_image="https://placehold.co/800x600/6b4429/f5ede1?text=Sliding+Wardrobe",
                 gallery_images="https://placehold.co/800x600/6b4429/f5ede1?text=Image+1",
                 location="Kukatpally, Hyderabad", material="BWP Plywood, Veneer Finish", duration="10 days",
                 completion_year="2024",
                 description="A 3-door sliding wardrobe designed to fit a compact bedroom without compromising storage. Placeholder project - replace with your own work.",
                 customer_requirements="Space saving design, mirror on one panel.",
                 testimonial_text="Smooth sliding doors and neat finishing. Good work overall.",
                 testimonial_author="Placeholder Customer", is_featured=False),
        ]
        for d in demo:
            db.session.add(Project(**d))

    if Testimonial.query.first() is None:
        demo_t = [
            dict(customer_name="Placeholder Customer", rating=5,
                 review="Excellent finishing and good quality woodwork. The team completed our main door beautifully.",
                 category="Doors",
                 profile_image="https://placehold.co/120x120/8b5a2b/f5ede1?text=P"),
            dict(customer_name="Placeholder Customer", rating=5,
                 review="Very professional team, delivered our modular kitchen exactly as planned and on time.",
                 category="Kitchen",
                 profile_image="https://placehold.co/120x120/8b5a2b/f5ede1?text=P"),
            dict(customer_name="Placeholder Customer", rating=4,
                 review="Good quality wardrobe at a fair price. Would recommend for bedroom furniture.",
                 category="Wardrobes",
                 profile_image="https://placehold.co/120x120/8b5a2b/f5ede1?text=P"),
        ]
        for d in demo_t:
            db.session.add(Testimonial(**d))

    db.session.commit()


def register_context_processors(app):
    @app.context_processor
    def inject_business():
        business = Settings.query.first()
        return dict(
            business=business,
            categories=PROJECT_CATEGORIES,
            now_year=datetime.now().year,
        )


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_id"):
            return redirect(url_for("admin_login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_IMAGE_EXTENSIONS


def save_upload(file_storage, category="misc"):
    """Saves an uploaded image under /uploads/<category>/ and returns its public path."""
    if not file_storage or file_storage.filename == "":
        return ""
    if not allowed_file(file_storage.filename):
        return ""
    ext = file_storage.filename.rsplit(".", 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    folder = os.path.join(Config.UPLOAD_FOLDER, secure_filename(category))
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    file_storage.save(path)
    return f"/uploads/{secure_filename(category)}/{filename}"


def register_routes(app):

    # ------------------------------------------------------------------ #
    # Public pages
    # ------------------------------------------------------------------ #
    @app.route("/")
    def index():
        featured = Project.query.filter_by(is_featured=True).order_by(Project.created_at.desc()).limit(6).all()
        testimonials = Testimonial.query.limit(6).all()
        return render_template("index.html", services=SERVICES[:8], featured=featured, testimonials=testimonials)

    @app.route("/about")
    def about():
        return render_template("about.html")

    @app.route("/services")
    def services():
        return render_template("services.html", services=SERVICES)

    @app.route("/our-works")
    def works():
        category = request.args.get("category", "")
        query = Project.query
        if category:
            query = query.filter_by(category=category)
        projects = query.order_by(Project.created_at.desc()).all()
        return render_template("works.html", projects=projects, active_category=category,
                                subcategories=PROJECT_SUBCATEGORIES)

    @app.route("/our-works/project/<int:project_id>")
    def project_details(project_id):
        project = Project.query.get_or_404(project_id)
        related = Project.query.filter(Project.category == project.category,
                                        Project.id != project.id).limit(3).all()
        return render_template("project_details.html", project=project, related=related)

    @app.route("/gallery")
    def gallery():
        category = request.args.get("category", "all")
        query = Project.query
        if category != "all":
            query = query.filter_by(category=category)
        projects = query.order_by(Project.created_at.desc()).all()
        return render_template("gallery.html", projects=projects, active_category=category)

    @app.route("/contact", methods=["GET", "POST"])
    def contact():
        if request.method == "POST":
            enquiry = Enquiry(
                kind="contact",
                name=request.form.get("name", "").strip(),
                phone=request.form.get("phone", "").strip(),
                email=request.form.get("email", "").strip(),
                message=request.form.get("message", "").strip(),
            )
            if not enquiry.name or not enquiry.phone:
                flash("Please provide at least your name and mobile number.", "error")
                return redirect(url_for("contact"))
            db.session.add(enquiry)
            db.session.commit()
            flash("Thank you! We will contact you shortly.", "success")
            return redirect(url_for("contact"))
        return render_template("contact.html")

    @app.route("/get-quote", methods=["GET", "POST"])
    def quote():
        if request.method == "POST":
            ref_image = save_upload(request.files.get("reference_image"), category="enquiry-references")
            enquiry = Enquiry(
                kind="quote",
                name=request.form.get("name", "").strip(),
                phone=request.form.get("phone", "").strip(),
                email=request.form.get("email", "").strip(),
                service=request.form.get("service", "").strip(),
                location=request.form.get("location", "").strip(),
                budget=request.form.get("budget", "").strip(),
                completion_date=request.form.get("completion_date", "").strip(),
                reference_image=ref_image,
                message=request.form.get("message", "").strip(),
            )
            if not enquiry.name or not enquiry.phone or not enquiry.service:
                flash("Please provide your name, mobile number and the service required.", "error")
                return redirect(url_for("quote"))
            db.session.add(enquiry)
            db.session.commit()
            flash("Thank you! We will contact you shortly.", "success")
            return redirect(url_for("quote"))
        preselect = request.args.get("service", "")
        return render_template("quote.html", preselect=preselect)

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        return send_from_directory(Config.UPLOAD_FOLDER, filename)

    # ------------------------------------------------------------------ #
    # Admin
    # ------------------------------------------------------------------ #
    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            admin = Admin.query.filter_by(username=username).first()
            if admin and admin.check_password(password):
                session["admin_id"] = admin.id
                session["admin_username"] = admin.username
                flash("Welcome back!", "success")
                return redirect(request.args.get("next") or url_for("admin_dashboard"))
            flash("Invalid username or password.", "error")
        return render_template("admin/login.html")

    @app.route("/admin/logout")
    def admin_logout():
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("admin_login"))

    @app.route("/admin")
    @login_required
    def admin_dashboard():
        stats = {
            "projects": Project.query.count(),
            "new_enquiries": Enquiry.query.filter_by(status="new").count(),
            "total_enquiries": Enquiry.query.count(),
            "testimonials": Testimonial.query.count(),
        }
        recent_enquiries = Enquiry.query.order_by(Enquiry.created_at.desc()).limit(5).all()
        return render_template("admin/dashboard.html", stats=stats, recent_enquiries=recent_enquiries)

    @app.route("/admin/projects")
    @login_required
    def admin_manage_projects():
        projects = Project.query.order_by(Project.created_at.desc()).all()
        return render_template("admin/manage_projects.html", projects=projects)

    @app.route("/admin/projects/add", methods=["GET", "POST"])
    @login_required
    def admin_add_project():
        if request.method == "POST":
            category = request.form.get("category")
            cover = save_upload(request.files.get("cover_image"), category=category) or \
                request.form.get("cover_image_url", "").strip()
            gallery_paths = []
            for f in request.files.getlist("gallery_images"):
                p = save_upload(f, category=category)
                if p:
                    gallery_paths.append(p)
            before_img = save_upload(request.files.get("before_image"), category=category)
            after_img = save_upload(request.files.get("after_image"), category=category)

            project = Project(
                title=request.form.get("title", "").strip(),
                category=category,
                subcategory=request.form.get("subcategory", "").strip(),
                cover_image=cover or "https://placehold.co/800x600/5b3a24/f5ede1?text=Add+Photo",
                gallery_images=",".join(gallery_paths),
                before_image=before_img,
                after_image=after_img,
                location=request.form.get("location", "").strip(),
                material=request.form.get("material", "").strip(),
                duration=request.form.get("duration", "").strip(),
                completion_year=request.form.get("completion_year", "").strip(),
                description=request.form.get("description", "").strip(),
                customer_requirements=request.form.get("customer_requirements", "").strip(),
                testimonial_text=request.form.get("testimonial_text", "").strip(),
                testimonial_author=request.form.get("testimonial_author", "").strip(),
                is_featured=bool(request.form.get("is_featured")),
            )
            db.session.add(project)
            db.session.commit()
            flash("Project added successfully.", "success")
            return redirect(url_for("admin_manage_projects"))
        return render_template("admin/add_project.html", categories=PROJECT_CATEGORIES,
                                subcategories=PROJECT_SUBCATEGORIES, project=None)

    @app.route("/admin/projects/edit/<int:project_id>", methods=["GET", "POST"])
    @login_required
    def admin_edit_project(project_id):
        project = Project.query.get_or_404(project_id)
        if request.method == "POST":
            project.title = request.form.get("title", "").strip()
            project.category = request.form.get("category")
            project.subcategory = request.form.get("subcategory", "").strip()
            project.location = request.form.get("location", "").strip()
            project.material = request.form.get("material", "").strip()
            project.duration = request.form.get("duration", "").strip()
            project.completion_year = request.form.get("completion_year", "").strip()
            project.description = request.form.get("description", "").strip()
            project.customer_requirements = request.form.get("customer_requirements", "").strip()
            project.testimonial_text = request.form.get("testimonial_text", "").strip()
            project.testimonial_author = request.form.get("testimonial_author", "").strip()
            project.is_featured = bool(request.form.get("is_featured"))

            new_cover = save_upload(request.files.get("cover_image"), category=project.category)
            if new_cover:
                project.cover_image = new_cover
            new_before = save_upload(request.files.get("before_image"), category=project.category)
            if new_before:
                project.before_image = new_before
            new_after = save_upload(request.files.get("after_image"), category=project.category)
            if new_after:
                project.after_image = new_after
            new_gallery = []
            for f in request.files.getlist("gallery_images"):
                p = save_upload(f, category=project.category)
                if p:
                    new_gallery.append(p)
            if new_gallery:
                existing = project.image_list
                project.gallery_images = ",".join(existing + new_gallery)

            db.session.commit()
            flash("Project updated successfully.", "success")
            return redirect(url_for("admin_manage_projects"))
        return render_template("admin/add_project.html", categories=PROJECT_CATEGORIES,
                                subcategories=PROJECT_SUBCATEGORIES, project=project)

    @app.route("/admin/projects/delete/<int:project_id>", methods=["POST"])
    @login_required
    def admin_delete_project(project_id):
        project = Project.query.get_or_404(project_id)
        db.session.delete(project)
        db.session.commit()
        flash("Project deleted.", "success")
        return redirect(url_for("admin_manage_projects"))

    @app.route("/admin/enquiries")
    @login_required
    def admin_enquiries():
        kind = request.args.get("kind", "")
        query = Enquiry.query
        if kind:
            query = query.filter_by(kind=kind)
        enquiries = query.order_by(Enquiry.created_at.desc()).all()
        return render_template("admin/enquiries.html", enquiries=enquiries, active_kind=kind)

    @app.route("/admin/enquiries/status/<int:enquiry_id>", methods=["POST"])
    @login_required
    def admin_update_enquiry_status(enquiry_id):
        enquiry = Enquiry.query.get_or_404(enquiry_id)
        enquiry.status = request.form.get("status", enquiry.status)
        db.session.commit()
        return redirect(url_for("admin_enquiries"))

    @app.route("/admin/settings", methods=["GET", "POST"])
    @login_required
    def admin_settings():
        settings = Settings.query.first()
        if request.method == "POST":
            for field in ["business_name", "tagline", "phone", "whatsapp", "email",
                          "address_line1", "address_line2", "area", "city", "state", "pincode",
                          "country", "hours_weekday", "hours_sunday", "map_embed_url", "map_lat",
                          "map_lng", "facebook", "instagram", "youtube", "whatsapp_message",
                          "years_experience", "projects_completed", "happy_customers"]:
                setattr(settings, field, request.form.get(field, getattr(settings, field)))
            db.session.commit()
            flash("Business settings updated across the entire website.", "success")
            return redirect(url_for("admin_settings"))
        return render_template("admin/settings.html", settings=settings)


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
