"""
Database models for SUKMAR WOOD WORKS.

Written with plain, portable SQLAlchemy column types (String, Text,
Integer, DateTime, Boolean) so this works unchanged on SQLite (development)
or MySQL (production) - only the SQLALCHEMY_DATABASE_URI in config.py
needs to change.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class Settings(db.Model):
    """
    Single-row table holding every piece of business information used
    across the whole website. Only ONE row will ever exist (id=1).
    Editing this row from the admin panel instantly changes the header,
    footer, contact page, quote page, WhatsApp button, Call button and
    Google Map on every page.
    """
    __tablename__ = "settings"

    id = db.Column(db.Integer, primary_key=True)

    business_name = db.Column(db.String(150), nullable=False, default="SUKMAR WOOD WORKS")
    tagline = db.Column(db.String(255), nullable=False, default="Quality Woodwork for Every Home")

    phone = db.Column(db.String(30), nullable=False, default="")
    whatsapp = db.Column(db.String(30), nullable=False, default="")
    email = db.Column(db.String(120), nullable=False, default="")

    address_line1 = db.Column(db.String(255), default="")
    address_line2 = db.Column(db.String(255), default="")
    area = db.Column(db.String(120), default="")
    city = db.Column(db.String(120), default="")
    state = db.Column(db.String(120), default="")
    pincode = db.Column(db.String(20), default="")
    country = db.Column(db.String(80), default="India")

    hours_weekday = db.Column(db.String(120), default="")
    hours_sunday = db.Column(db.String(120), default="")

    map_embed_url = db.Column(db.Text, default="")
    map_lat = db.Column(db.String(30), default="")
    map_lng = db.Column(db.String(30), default="")

    facebook = db.Column(db.String(255), default="")
    instagram = db.Column(db.String(255), default="")
    youtube = db.Column(db.String(255), default="")

    whatsapp_message = db.Column(db.Text, default="")

    years_experience = db.Column(db.String(10), default="0")
    projects_completed = db.Column(db.String(10), default="0")
    happy_customers = db.Column(db.String(10), default="0")

    # ---- convenience helpers ----
    @property
    def whatsapp_digits(self):
        return "".join(ch for ch in (self.whatsapp or "") if ch.isdigit())

    @property
    def phone_digits(self):
        return "".join(ch for ch in (self.phone or "") if ch.isdigit())

    @property
    def full_address(self):
        parts = [self.address_line1, self.address_line2, self.area,
                 f"{self.city}, {self.state}", f"PIN: {self.pincode}", self.country]
        return ", ".join([p for p in parts if p])


class Admin(db.Model):
    __tablename__ = "admins"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


# Categories shown throughout Services / Our Works / Gallery / Admin
PROJECT_CATEGORIES = {
    "doors": "Doors",
    "windows": "Windows",
    "kitchen": "Kitchen",
    "wardrobes": "Wardrobes",
    "furniture": "Furniture",
    "tv-units": "TV Units",
    "pooja-units": "Pooja Units",
    "cupboards": "Cupboards",
    "office-furniture": "Office Furniture",
    "wooden-ceiling": "Wooden Ceiling",
    "other": "Other Wood Works",
}

PROJECT_SUBCATEGORIES = {
    "doors": ["Main Door", "Teak Door", "Designer Door", "Bedroom Door", "Double Door", "Traditional Door"],
    "windows": ["Wooden Window", "Sliding Window", "Glass Window", "Balcony Window", "Teak Window"],
    "kitchen": ["Modular Kitchen", "L-Shaped Kitchen", "U-Shaped Kitchen", "Island Kitchen"],
    "wardrobes": ["Sliding Wardrobe", "Hinged Wardrobe", "Walk-in Wardrobe"],
    "furniture": ["Wooden Bed", "Dining Table", "Sofa", "Chairs", "Study Table", "Bookshelf"],
    "tv-units": ["TV Unit"],
    "pooja-units": ["Pooja Unit"],
    "cupboards": ["Cupboard"],
    "office-furniture": ["Office Furniture"],
    "wooden-ceiling": ["Wooden Ceiling"],
    "other": ["Custom Woodwork"],
}


class Project(db.Model):
    """One completed customer project shown in 'Our Works' / Gallery."""
    __tablename__ = "projects"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(50), nullable=False)          # key from PROJECT_CATEGORIES
    subcategory = db.Column(db.String(100), default="")

    cover_image = db.Column(db.String(255), default="")           # path under /uploads or placeholder url
    gallery_images = db.Column(db.Text, default="")                # comma-separated list of image paths
    before_image = db.Column(db.String(255), default="")
    after_image = db.Column(db.String(255), default="")

    location = db.Column(db.String(150), default="")
    material = db.Column(db.String(150), default="")
    duration = db.Column(db.String(80), default="")
    completion_year = db.Column(db.String(10), default="")

    description = db.Column(db.Text, default="")
    customer_requirements = db.Column(db.Text, default="")
    testimonial_text = db.Column(db.Text, default="")
    testimonial_author = db.Column(db.String(120), default="")

    is_featured = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def image_list(self):
        return [p.strip() for p in (self.gallery_images or "").split(",") if p.strip()]

    @property
    def category_label(self):
        return PROJECT_CATEGORIES.get(self.category, self.category.title())


class Enquiry(db.Model):
    """Stores both Contact-page messages and Get-Quote requests."""
    __tablename__ = "enquiries"

    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.String(20), nullable=False, default="contact")   # 'contact' or 'quote'

    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(120), default="")

    service = db.Column(db.String(80), default="")
    location = db.Column(db.String(150), default="")
    budget = db.Column(db.String(80), default="")
    completion_date = db.Column(db.String(40), default="")
    reference_image = db.Column(db.String(255), default="")

    message = db.Column(db.Text, default="")
    status = db.Column(db.String(20), default="new")    # new / contacted / closed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Testimonial(db.Model):
    """Homepage customer testimonials (independent of a specific project)."""
    __tablename__ = "testimonials"

    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(120), nullable=False)
    profile_image = db.Column(db.String(255), default="")
    rating = db.Column(db.Integer, default=5)
    review = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(80), default="")
    is_placeholder = db.Column(db.Boolean, default=True)
