# SUKMAR WOOD WORKS — Website

A premium, fully responsive website for SUKMAR WOOD WORKS (woodworking, carpentry,
doors, windows, modular kitchens and interior wood works), built with Flask +
SQLite, with a full admin panel so the business owner can manage everything
without touching code.

---

## 1. What's inside

```
sukmar-wood-works/
├── app.py                 # Flask app: all routes (public + admin)
├── config.py              # Starting business info + app settings (see note below)
├── models.py               # Database tables (Settings, Admin, Project, Enquiry, Testimonial)
├── requirements.txt
│
├── templates/              # All public pages
│   ├── base.html            # Header, nav, footer, floating WhatsApp/Call — shared by every page
│   ├── index.html            # Home page
│   ├── about.html
│   ├── services.html
│   ├── works.html            # "Our Works" portfolio, filterable by category
│   ├── project_details.html  # Single project page (images, before/after, testimonial)
│   ├── gallery.html          # Masonry gallery with lightbox + category filters
│   ├── contact.html          # Contact form + Google Map
│   ├── quote.html            # Get Quote enquiry form
│   └── admin/                # Admin panel pages (login, dashboard, projects, enquiries, settings)
│
├── static/
│   ├── css/style.css         # Design system (colors, type, components) + admin.css
│   ├── js/script.js          # Counters, gallery filter, lightbox, nav scroll effect
│   └── images/
│
├── gallery/                 # Reference folder structure for organising project photos
│   ├── doors/ (main-door, teak-door, designer-door, bedroom-door, double-door, traditional-door)
│   ├── windows/ (wooden-window, sliding-window, glass-window, balcony-window, teak-window)
│   ├── kitchen/ (project-01, project-02, project-03)
│   ├── wardrobes/ (sliding, hinged, walk-in)
│   ├── furniture/ (beds, tables, chairs, sofa, ...)
│   ├── tv-units/, pooja-units/, cupboards/, office-furniture/, wooden-ceiling/
│
├── uploads/                 # Photos uploaded through the Admin Panel are saved here automatically
└── database/database.db     # SQLite database (created automatically on first run)
```

> **Note on `gallery/` vs `uploads/`:** the `gallery/` folder above is kept as the
> reference category structure described in the project brief. In practice,
> every photo you upload through the **Admin Panel** is saved automatically
> into `uploads/<category>/` and linked to the right project in the database —
> you do not need to manually place files into the `gallery/` folders. This is
> deliberate: it means a non-technical owner never has to touch the file
> system directly.

---

## 2. Running the website (development)

```bash
cd sukmar-wood-works
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:5000** in your browser.

The first time it runs, the app automatically:
- Creates the SQLite database at `database/database.db`
- Loads your real business details (name, phone, WhatsApp, email, address, hours) from `config.py`
- Creates an admin login (see below)
- Adds a few clearly-labelled **placeholder** projects and testimonials so the site isn't empty — replace these from the admin panel with your real project photos and real customer reviews.

## 3. Admin Panel

URL: **http://localhost:5000/admin/login**

| Field | Default |
|---|---|
| Username | `admin` |
| Password | `sukmar@2026` |

**Please change this password immediately** — go to your production server's
environment and update the `Admin` record, or ask your developer to add a
"change password" screen before going live. The current build focuses on the
management features described in the brief (projects, enquiries, business
settings); a password-change screen is a natural next addition.

### What you can do in the Admin Panel
- **Dashboard** — quick overview: number of projects, new enquiries, testimonials.
- **Projects** — Add / Edit / Delete portfolio projects. For each project you can set:
  category & sub-category, cover photo, multiple gallery photos, before/after
  photos, location, material used, duration, completion year, description,
  customer requirements, and a customer testimonial. Projects marked
  "Featured" appear on the Home page automatically.
- **Enquiries** — every submission from the **Contact** page and the **Get Quote**
  page lands here automatically, with phone/email click-to-contact links and a
  status you can update (New / Contacted / Closed).
- **Business Settings** — the single place to update your **phone number,
  WhatsApp number, email, address, working hours, Google Map link and social
  links**. Saving here updates the Header, Footer, Home page, Contact page,
  Get Quote page, WhatsApp button, Call button and Google Map across the
  **entire website instantly** — nothing is hard-coded per page.

---

## 4. One central place for business information

All business information (name, phone, WhatsApp, email, address, hours, map,
social links) lives in **one database table** (`Settings`), edited from
**Admin → Business Settings**. Every template reads from this same record via
a shared `business` variable, so a single update propagates everywhere:
Header, Home, About, Contact, Footer, Get Quote, the floating WhatsApp/Call
buttons, and the Google Map.

`config.py` only provides the **starting values** the very first time the app
runs (and local dev settings like the secret key and database path) — after
that, always make changes through the Admin Panel, not by editing code.

---

## 5. Replacing placeholder content

- **Images:** every image currently shown (hero, services, sample projects,
  testimonial avatars) is a clearly labelled placeholder. Replace them by
  uploading real photos through **Admin → Projects → Add/Edit Project**.
- **Testimonials:** the three testimonials seeded on first run are marked as
  placeholders in the code (`is_placeholder=True`) and use generic reviewer
  names. Replace them with real customer reviews once you have them —
  do not present placeholder testimonials to customers as real feedback.
- **Sample projects:** the 3 demo projects are labelled "Placeholder project —
  replace with your own work" in their description. Delete or edit them from
  **Admin → Projects**.

---

## 6. Production notes

- **Database:** ships with SQLite (zero setup). To move to MySQL for
  production, set the `DATABASE_URL` environment variable, e.g.
  `mysql+pymysql://user:password@host/sukmar_wood_works` — no code changes
  needed, the models use portable column types.
- **Secret key:** set the `SECRET_KEY` environment variable to a random value
  in production instead of the development default in `config.py`.
- **File uploads:** stored under `/uploads`; make sure this folder is
  writable and backed up (or move to cloud storage like S3 for scale).
- **HTTPS:** deploy behind a proper web server (e.g. Gunicorn + Nginx) with
  HTTPS in production; `app.run(debug=True)` is for local development only.
