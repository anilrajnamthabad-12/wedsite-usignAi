document.addEventListener("DOMContentLoaded", function () {

  /* ---------------- Sticky navbar shadow on scroll ---------------- */
  const nav = document.querySelector(".main-nav");
  if (nav) {
    window.addEventListener("scroll", function () {
      nav.classList.toggle("scrolled", window.scrollY > 20);
    });
  }

  /* ---------------- Animated counters (About section) ---------------- */
  const counters = document.querySelectorAll(".count[data-target]");
  if (counters.length) {
    const animate = (el) => {
      const target = parseInt(el.getAttribute("data-target"), 10) || 0;
      const duration = 1400;
      const start = performance.now();
      const step = (now) => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.floor(eased * target).toLocaleString();
        if (progress < 1) requestAnimationFrame(step);
        else el.textContent = target.toLocaleString() + "+";
      };
      requestAnimationFrame(step);
    };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animate(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    counters.forEach((c) => observer.observe(c));
  }

  /* ---------------- Gallery / Works category filter (client-side) ---------------- */
  const filterButtons = document.querySelectorAll(".filter-btn[data-filter]");
  const filterItems = document.querySelectorAll("[data-category]");
  if (filterButtons.length && filterItems.length) {
    filterButtons.forEach((btn) => {
      btn.addEventListener("click", function () {
        filterButtons.forEach((b) => b.classList.remove("active"));
        this.classList.add("active");
        const filter = this.getAttribute("data-filter");
        filterItems.forEach((item) => {
          const match = filter === "all" || item.getAttribute("data-category") === filter;
          item.style.display = match ? "" : "none";
        });
      });
    });
  }

  /* ---------------- Lightbox for gallery images ---------------- */
  const lightboxImages = Array.from(document.querySelectorAll(".js-lightbox-img"));
  if (lightboxImages.length) {
    const overlay = document.createElement("div");
    overlay.className = "lightbox-overlay";
    overlay.innerHTML = `
      <button class="lightbox-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
      <button class="lightbox-prev" aria-label="Previous"><i class="fa-solid fa-chevron-left"></i></button>
      <img src="" alt="Project image">
      <button class="lightbox-next" aria-label="Next"><i class="fa-solid fa-chevron-right"></i></button>
      <div class="lightbox-caption"></div>
    `;
    document.body.appendChild(overlay);
    const imgEl = overlay.querySelector("img");
    const captionEl = overlay.querySelector(".lightbox-caption");
    let currentIndex = 0;

    const show = (index) => {
      currentIndex = (index + lightboxImages.length) % lightboxImages.length;
      const target = lightboxImages[currentIndex];
      imgEl.src = target.getAttribute("data-full") || target.src;
      captionEl.textContent = target.getAttribute("data-caption") || "";
      overlay.classList.add("active");
    };

    lightboxImages.forEach((img, index) => {
      img.style.cursor = "zoom-in";
      img.addEventListener("click", () => show(index));
    });

    overlay.querySelector(".lightbox-close").addEventListener("click", () => overlay.classList.remove("active"));
    overlay.querySelector(".lightbox-prev").addEventListener("click", () => show(currentIndex - 1));
    overlay.querySelector(".lightbox-next").addEventListener("click", () => show(currentIndex + 1));
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.classList.remove("active"); });
    document.addEventListener("keydown", (e) => {
      if (!overlay.classList.contains("active")) return;
      if (e.key === "Escape") overlay.classList.remove("active");
      if (e.key === "ArrowLeft") show(currentIndex - 1);
      if (e.key === "ArrowRight") show(currentIndex + 1);
    });
  }

  /* ---------------- Bootstrap form validation feedback ---------------- */
  document.querySelectorAll("form.needs-validation").forEach((form) => {
    form.addEventListener("submit", function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add("was-validated");
    });
  });
});
