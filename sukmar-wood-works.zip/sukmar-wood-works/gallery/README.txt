This folder shows the reference category structure for organizing project photos,
as outlined in the project brief.

IMPORTANT: You do NOT need to manually copy photos into these folders.

Instead, use the Admin Panel (yourwebsite.com/admin/login):
  Admin -> Projects -> Add New Project -> choose a category -> upload photos

Uploaded photos are automatically saved and linked to the correct project,
and will appear in the right place on "Our Works" and "Gallery" pages.

This folder is kept only as a category reference / for any manual archival
of raw photos you want to keep organized outside the website.
